package com.example.birthdayreminderlast_10

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
