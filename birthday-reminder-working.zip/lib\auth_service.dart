import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Current user getter
  User? get currentUser => _auth.currentUser;

  // Auth state changes stream
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Email/Password Registration
  Future<User?> registerWithEmailAndPassword(String email, String password) async {
    try {
      final result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return result.user;
    } catch (e) {
      print('Registration error: $e');
      return null;
    }
  }

  // Email/Password Sign In
  Future<User?> signInWithEmailAndPassword(String email, String password) async {
    try {
      final result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return result.user;
    } catch (e) {
      print('Sign in error: $e');
      return null;
    }
  }

  // Google Sign In
  Future<User?> signInWithGoogle() async {
    try {
      if (kIsWeb) {
        // Web platformu için popup kullan
        final googleProvider = GoogleAuthProvider();
        final result = await _auth.signInWithPopup(googleProvider);
        return result.user;
      } else {
        // Mobil platformlar için normal akış
        final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
        if (googleUser == null) return null;

        final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
        final credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );

        final result = await _auth.signInWithCredential(credential);
        return result.user;
      }
    } catch (e) {
      print('Google sign in error: $e');
      return null;
    }
  }

  // GitHub Sign In
  Future<User?> signInWithGitHub() async {
    try {
      final githubProvider = GithubAuthProvider();
      
      if (kIsWeb) {
        // Web platformu için popup kullan
        final result = await _auth.signInWithPopup(githubProvider);
        return result.user;
      } else {
        // Mobil platformlarda henüz desteklenmiyor
        print('GitHub login is not supported on mobile platforms yet');
        return null;
      }
    } catch (e) {
      print('GitHub sign in error: $e');
      return null;
    }
  }

  // Sign Out
  Future<void> signOut() async {
    try {
      await _auth.signOut();
      if (!kIsWeb) {
        await GoogleSignIn().signOut();
      }
    } catch (e) {
      print('Sign out error: $e');
    }
  }

  // Password Reset
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      print('Password reset error: $e');
    }
  }
}

// Custom User class
class AppUser {
  final String uid;
  final String? email;

  AppUser({required this.uid, this.email});
}
