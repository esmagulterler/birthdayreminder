import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';

class BirthdayService {
  final SupabaseClient _supabase = Supabase.instance.client;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get _userId => _auth.currentUser?.uid;

  /// Test Supabase bağlantısı
  Future<bool> testConnection() async {
    try {
      if (_userId == null) {
        print('User not authenticated');
        return false;
      }

      print('Testing Supabase connection for user: $_userId');
      
      // Önce sadece genel bağlantıyı test et
      final response = await _supabase
          .from('birthdays')
          .select()
          .limit(1);
      
      print('Connection test successful: $response');
      return true;
    } catch (e) {
      print('Connection test failed: $e');
      if (e is PostgrestException) {
        print('Postgrest error details:');
        print('Message: ${e.message}');
        print('Details: ${e.details}');
        print('Hint: ${e.hint}');
        print('Code: ${e.code}');
        
        // Eğer tablo yoksa, alternatif çözüm öner
        if (e.code == 'PGRST116' || e.message.contains('relation') || e.message.contains('does not exist')) {
          print('UYARI: birthdays tablosu Supabase\'de mevcut değil!');
          print('Lütfen Supabase panelinde aşağıdaki SQL\'i çalıştırın:');
          print('');
          print('CREATE TABLE birthdays (');
          print('  id BIGSERIAL PRIMARY KEY,');
          print('  user_id TEXT NOT NULL,');
          print('  name TEXT NOT NULL,');
          print('  birthday_date DATE NOT NULL,');
          print('  note TEXT DEFAULT \'\',');
          print('  created_at TIMESTAMPTZ DEFAULT NOW()');
          print(');');
          print('');
          print('Ardından RLS (Row Level Security) politikalarını etkinleştirin.');
        }
      }
      return false;
    }
  }

  /// Doğum günü ekleme
  Future<bool> addBirthday({
    required String name,
    required DateTime birthDate,
    String? note,
  }) async {
    try {
      if (_userId == null) {
        throw Exception('Kullanıcı oturumu bulunamadı');
      }

      print('Adding birthday for user: $_userId');
      print('Name: $name');
      print('Birth date: ${birthDate.toIso8601String().substring(0, 10)}');
      print('Note: ${note ?? "Boş"}');

      final data = {
        'user_id': _userId,
        'name': name,
        'birthday_date': birthDate.toIso8601String().substring(0, 10),
        'note': note ?? '',
        'created_at': DateTime.now().toIso8601String(),
      };

      print('Data to insert: $data');

      // RLS bypass için service_role key gerekiyor, 
      // şimdilik RLS olmadan denelim
      final response = await _supabase
          .from('birthdays')
          .insert(data)
          .select();

      print('Birthday added successfully: $response');
      return true;
    } catch (e) {
      print('Detailed error adding birthday: $e');
      print('Error type: ${e.runtimeType}');
      if (e is PostgrestException) {
        print('Postgrest error details:');
        print('Message: ${e.message}');
        print('Details: ${e.details}');
        print('Hint: ${e.hint}');
        print('Code: ${e.code}');
        
        // UUID hatası için özel mesaj
        if (e.code == '22P02' && e.message.contains('uuid')) {
          print('');
          print('ÇÖZÜM: Supabase\'de user_id sütunu UUID tipinde, Firebase UID ise TEXT tipinde.');
          print('Lütfen Supabase SQL Editor\'da şu komutu çalıştırın:');
          print('ALTER TABLE birthdays ALTER COLUMN user_id TYPE TEXT;');
          print('');
          print('Veya tabloyu silip tekrar oluşturun:');
          print('DROP TABLE birthdays;');
          print('CREATE TABLE birthdays (');
          print('  id BIGSERIAL PRIMARY KEY,');
          print('  user_id TEXT NOT NULL,');
          print('  name TEXT NOT NULL,');
          print('  birthday_date DATE NOT NULL,');
          print('  note TEXT DEFAULT \'\',');
          print('  created_at TIMESTAMPTZ DEFAULT NOW()');
          print(');');
          print('');
        }
      }
      return false;
    }
  }

  /// Doğum günü listesini getirir
  Future<List<Map<String, dynamic>>> getBirthdays() async {
    try {
      if (_userId == null) {
        return [];
      }

      final response = await _supabase
          .from('birthdays')
          .select()
          .eq('user_id', _userId!)
          .order('birthday_date');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error getting birthdays: $e');
      return [];
    }
  }

  /// Doğum günü güncelleme
  Future<bool> updateBirthday({
    required int id,
    required String newName,
    required DateTime newDate,
    String? gift,
    String? note,
  }) async {
    try {
      if (_userId == null) {
        throw Exception('Kullanıcı oturumu bulunamadı');
      }

      await _supabase.from('birthdays').update({
        'name': newName,
        'birthday_date': newDate.toIso8601String().substring(0, 10),
        'note': note ?? '',
      }).eq('id', id).eq('user_id', _userId!);

      return true;
    } catch (e) {
      print('Error updating birthday: $e');
      return false;
    }
  }

  /// Doğum günü silme
  Future<bool> deleteBirthday(int id) async {
    try {
      if (_userId == null) {
        throw Exception('Kullanıcı oturumu bulunamadı');
      }

      await _supabase
          .from('birthdays')
          .delete()
          .eq('id', id)
          .eq('user_id', _userId!);

      return true;
    } catch (e) {
      print('Error deleting birthday: $e');
      return false;
    }
  }

  /// Yaklaşan doğum günlerini getirir
  Future<List<Map<String, dynamic>>> getUpcomingBirthdays({
    int days = 30,
  }) async {
    try {
      if (_userId == null) {
        return [];
      }

      final response = await _supabase
          .from('birthdays')
          .select()
          .eq('user_id', _userId!);

      final birthdays = List<Map<String, dynamic>>.from(response);
      final now = DateTime.now();
      final upcoming = <Map<String, dynamic>>[];

      for (var birthday in birthdays) {
        final birthDate = DateTime.parse(birthday['birthday_date']);
        final thisYearBirthday = DateTime(now.year, birthDate.month, birthDate.day);
        
        final nextBirthday = thisYearBirthday.isBefore(now)
            ? DateTime(now.year + 1, birthDate.month, birthDate.day)
            : thisYearBirthday;

        final daysUntil = nextBirthday.difference(now).inDays;
        
        if (daysUntil <= days) {
          birthday['daysUntil'] = daysUntil;
          birthday['nextBirthday'] = nextBirthday;
          upcoming.add(Map<String, dynamic>.from(birthday));
        }
      }

      upcoming.sort((a, b) => a['daysUntil'].compareTo(b['daysUntil']));
      return upcoming;
    } catch (e) {
      print('Error getting upcoming birthdays: $e');
      return [];
    }
  }

  /// Bugünkü doğum günlerini getirir
  Future<List<Map<String, dynamic>>> getTodayBirthdays() async {
    try {
      if (_userId == null) {
        return [];
      }

      final now = DateTime.now();
      final response = await _supabase
          .from('birthdays')
          .select()
          .eq('user_id', _userId!);

      final birthdays = List<Map<String, dynamic>>.from(response);
      final today = <Map<String, dynamic>>[];

      for (var birthday in birthdays) {
        final birthDate = DateTime.parse(birthday['birthday_date']);
        if (birthDate.month == now.month && birthDate.day == now.day) {
          today.add(Map<String, dynamic>.from(birthday));
        }
      }

      return today;
    } catch (e) {
      print('Error getting today birthdays: $e');
      return [];
    }
  }

  /// İstatistikleri getirir
  Future<Map<String, int>> getStatistics() async {
    try {
      if (_userId == null) {
        return {'total': 0, 'thisMonth': 0, 'today': 0};
      }

      final response = await _supabase
          .from('birthdays')
          .select()
          .eq('user_id', _userId!);

      final birthdays = List<Map<String, dynamic>>.from(response);
      final now = DateTime.now();
      int thisMonth = 0;
      int today = 0;

      for (var birthday in birthdays) {
        final birthDate = DateTime.parse(birthday['birthday_date']);
        
        if (birthDate.month == now.month) {
          thisMonth++;
        }
        
        if (birthDate.month == now.month && birthDate.day == now.day) {
          today++;
        }
      }

      return {
        'total': birthdays.length,
        'thisMonth': thisMonth,
        'today': today,
      };
    } catch (e) {
      print('Error getting statistics: $e');
      return {'total': 0, 'thisMonth': 0, 'today': 0};
    }
  }

  /// Arama yapar
  Future<List<Map<String, dynamic>>> searchBirthdays(String query) async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        return [];
      }

      if (query.trim().isEmpty) {
        return await getBirthdays();
      }

      final response = await _supabase
          .from('birthdays')
          .select()
          .eq('user_id', user.uid)
          .ilike('name', '%$query%');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error searching birthdays: $e');
      return [];
    }
  }
}
