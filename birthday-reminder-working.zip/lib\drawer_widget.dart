import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'auth_service.dart';

class DrawerWidget extends StatelessWidget {
  const DrawerWidget({super.key});

  void _navigate(BuildContext context, String route) {
    Navigator.pop(context);
    if (ModalRoute.of(context)?.settings.name != route) {
      Navigator.pushReplacementNamed(context, route);
    }
  }

  void _logout(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Çıkış'),
          content: const Text('Çıkmak istediğinize emin misiniz?'),
          actions: [
            TextButton(
              child: const Text('İptal'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: const Text('Evet'),
              onPressed: () async {
                Navigator.of(context).pop();
                
                // Firebase'den gerçek çıkış yap
                final authService = AuthService();
                await authService.signOut();
                
                if (context.mounted) {
                  Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Başarıyla çıkış yapıldı')),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          // Firebase Auth kullanıcı bilgilerini göster
          StreamBuilder<User?>(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (context, snapshot) {
              final user = snapshot.data;
              
              return UserAccountsDrawerHeader(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.purple, Colors.purpleAccent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                accountName: Text(
                  user?.displayName ?? 'Kullanıcı',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                accountEmail: Text(
                  user?.email ?? 'Email bulunamadı',
                  style: const TextStyle(fontSize: 14),
                ),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: user?.photoURL != null
                      ? ClipOval(
                          child: Image.network(
                            user!.photoURL!,
                            fit: BoxFit.cover,
                            width: 90,
                            height: 90,
                            errorBuilder: (context, error, stackTrace) {
                              return const Icon(
                                Icons.person,
                                size: 50,
                                color: Colors.purple,
                              );
                            },
                          ),
                        )
                      : const Icon(
                          Icons.person,
                          size: 50,
                          color: Colors.purple,
                        ),
                ),
                otherAccountsPictures: [
                  IconButton(
                    icon: const Icon(Icons.cake, color: Colors.white),
                    onPressed: () => _navigate(context, '/'),
                  ),
                ],
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Ana Sayfa'),
            onTap: () => _navigate(context, '/'),
          ),
          ListTile(
            leading: const Icon(Icons.cake),
            title: const Text('Doğum Günleri'),
            onTap: () => _navigate(context, '/birthdays'),
          ),
          ListTile(
            leading: const Icon(Icons.add),
            title: const Text('Doğum Günü Ekle'),
            onTap: () => _navigate(context, '/add-birthday'),
          ),
          ListTile(
            leading: const Icon(Icons.notifications),
            title: const Text('Bildirimler'),
            onTap: () => _navigate(context, '/notifications'),
          ),
          ListTile(
            leading: const Icon(Icons.history),
            title: const Text('Geçmiş'),
            onTap: () => _navigate(context, '/history'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('Profil'),
            onTap: () => _navigate(context, '/profile'),
          ),
          const Divider(),
          // Kullanıcı bilgileri
          StreamBuilder<User?>(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (context, snapshot) {
              final user = snapshot.data;
              if (user == null) return const SizedBox.shrink();
              
              return Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.info_outline, size: 20),
                    title: const Text('Kullanıcı ID', style: TextStyle(fontSize: 12)),
                    subtitle: Text(
                      user.uid.substring(0, 8) + '...',
                      style: const TextStyle(fontSize: 10),
                    ),
                    dense: true,
                  ),
                  ListTile(
                    leading: const Icon(Icons.access_time, size: 20),
                    title: const Text('Kayıt Tarihi', style: TextStyle(fontSize: 12)),
                    subtitle: Text(
                      user.metadata.creationTime?.toString().substring(0, 10) ?? 'Bilinmiyor',
                      style: const TextStyle(fontSize: 10),
                    ),
                    dense: true,
                  ),
                  const Divider(),
                ],
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.exit_to_app, color: Colors.red),
            title: const Text('Çıkış', style: TextStyle(color: Colors.red)),
            onTap: () => _logout(context),
          ),
        ],
      ),
    );
  }
}