import 'package:flutter/material.dart';
import 'custom_app_bar.dart';
import 'drawer_widget.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Geçmiş'),
      drawer: const DrawerWidget(),
      body: const Center(
        child: Text(
          'Geçmiş Sayfası',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
