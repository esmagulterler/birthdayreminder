import 'package:flutter/material.dart';
import 'custom_app_bar.dart';
import 'drawer_widget.dart';

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Bildirimler'),
      drawer: const DrawerWidget(),
      body: const Center(
        child: Text(
          'Bildirimler Sayfası',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
} 