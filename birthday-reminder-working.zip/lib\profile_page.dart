import 'package:flutter/material.dart';
import 'user_local_storage.dart';
import 'edit_profile_page.dart';
import 'custom_app_bar.dart';
import 'drawer_widget.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  // Kullanıcı adı için değişken
  String userName = '';
  // Kullanıcı e-posta adresi için değişken
  String userEmail = '';
  // Kullanıcı fotoğraf URL'si (isteğe bağlı)
  String? photoURL;
  // Yüklenme durumu kontrolü
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    // Sayfa açılır açılmaz kullanıcı verilerini yükle
    _loadUserData();
  }

  // Kullanıcı verilerini yerel depolamadan çekme fonksiyonu
  Future<void> _loadUserData() async {
    try {
      final userLocalStorage = UserLocalStorage();
      
      // Yerel depolamadan kullanıcı verilerini al
      final email = await userLocalStorage.getString('email');
      final firstName = await userLocalStorage.getString('firstName');
      final lastName = await userLocalStorage.getString('lastName');

      setState(() {
        // Kullanıcı adı, e-posta ve fotoğraf URL'sini güncelle
        userName = '${firstName ?? ''} ${lastName ?? ''}'.trim();
        if (userName.isEmpty) {
          userName = email?.split('@')[0] ?? 'Kullanıcı';
        }
        userEmail = email ?? 'email@example.com';
        photoURL = null; // Yerel depolamada fotoğraf URL'si yok
        isLoading = false;
      });
    } catch (e) {
      // Hata durumunda konsola yazdır ve yüklenme durumunu false yap
      debugPrint('Kullanıcı verisi yüklenemedi: $e');
      setState(() {
        userName = 'Kullanıcı';
        userEmail = 'email@example.com';
        isLoading = false;
      });
    }
  }

  // Kullanıcı çıkış yapma fonksiyonu
  Future<void> _logout() async {
    try {
      final userLocalStorage = UserLocalStorage();
      await userLocalStorage.clearAll();
      
      if (mounted) {
        // Çıkış yapıldıktan sonra login sayfasına yönlendir
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Başarıyla çıkış yapıldı'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Çıkış yapılırken hata oluştu: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Widget _buildSection({required String title, required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.0),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.1),
            spreadRadius: 1,
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: Colors.blue.shade700,
            ),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _buildCard({required Widget child}) {
    return Card(
      elevation: 4.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: child,
      ),
    );
  }

  // Profil bilgilerini gösteren widget'ı oluştur
  Widget _buildProfileContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Profil kartı
            _buildCard(
              child: Column(
                children: [
                  // Kullanıcı fotoğrafı ya da ilk harfi gösteren avatar
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.blue.shade100,
                    backgroundImage: photoURL != null ? AssetImage(photoURL!) : null,
                    child: photoURL == null
                        ? Text(
                            userName.isNotEmpty ? userName[0].toUpperCase() : 'K',
                            style: TextStyle(
                              fontSize: 50,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue.shade700,
                            ),
                          )
                        : null,
                  ),
                  const SizedBox(height: 24),
                  
                  // Kullanıcı adı
                  Text(
                    userName,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  
                  // Kullanıcı e-posta
                  Text(
                    userEmail,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Profil bilgileri
            _buildSection(
              title: 'Profil Bilgileri',
              child: Column(
                children: [
                  _buildInfoRow(
                    icon: Icons.person,
                    title: 'Ad Soyad',
                    value: userName,
                  ),
                  const Divider(),
                  _buildInfoRow(
                    icon: Icons.email,
                    title: 'E-posta',
                    value: userEmail,
                  ),
                  const Divider(),
                  _buildInfoRow(
                    icon: Icons.calendar_today,
                    title: 'Üyelik Tarihi',
                    value: 'Mart 2024',
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // İstatistikler
            _buildSection(
              title: 'İstatistikler',
              child: Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      icon: Icons.cake,
                      title: 'Doğum Günleri',
                      value: '12',
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildStatCard(
                      icon: Icons.notifications,
                      title: 'Bildirimler',
                      value: '5',
                      color: Colors.green,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildStatCard(
                      icon: Icons.favorite,
                      title: 'Favoriler',
                      value: '3',
                      color: Colors.orange,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // Aksiyon butonları
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      // Düzenleme sayfasına git ve sonucu bekle
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const EditProfilePage()),
                      );
                      // Eğer düzenleme yapıldıysa kullanıcı verilerini tekrar yükle
                      if (result == true) {
                        await _loadUserData();
                      }
                    },
                    icon: const Icon(Icons.edit),
                    label: const Text('Profili Düzenle'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade600,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _logout,
                    icon: const Icon(Icons.logout),
                    label: const Text('Çıkış Yap'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.red.shade600,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: Colors.blue.shade600, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 24, color: color),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              color: color.withValues(alpha: 0.8),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Scaffold kullanarak sayfa yapısını oluştur
    return Scaffold(
      appBar: CustomAppBar(title: 'Profil'),
      drawer: const DrawerWidget(),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildProfileContent(),
    );
  }
} 