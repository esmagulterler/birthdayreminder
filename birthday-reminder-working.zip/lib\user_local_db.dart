import 'package:shared_preferences/shared_preferences.dart';

class UserLocalDB {
  // SharedPreferences nesnesi, başlangıçta null
  static SharedPreferences? _prefs;

  // SharedPreferences'a erişim için getter
  static Future<SharedPreferences> get prefs async {
    if (_prefs != null) return _prefs!;
    _prefs = await SharedPreferences.getInstance();
    return _prefs!;
  }

  // Kullanıcı bilgilerini yerel depolamaya ekleme veya güncelleme fonksiyonu
  static Future<void> insertUser({
    required String uid,
    required String name,
    required String email,
  }) async {
    final preferences = await prefs;
    await preferences.setString('uid', uid);
    await preferences.setString('name', name);
    await preferences.setString('email', email);
  }

  // Yerel depolamadan kullanıcı bilgisi çekme fonksiyonu
  // Eğer kullanıcı yoksa null döner
  static Future<Map<String, dynamic>?> getUser() async {
    final preferences = await prefs;
    final uid = preferences.getString('uid');
    final name = preferences.getString('name');
    final email = preferences.getString('email');

    // Eğer uid varsa kullanıcı bilgilerini döndür
    if (uid != null) {
      return {
        'uid': uid,
        'name': name ?? '',
        'email': email ?? '',
      };
    }
    return null;
  }

  // Kullanıcı bilgilerini temizleme (silme) fonksiyonu
  static Future<void> clearUser() async {
    final preferences = await prefs;
    await preferences.remove('uid');
    await preferences.remove('name');
    await preferences.remove('email');
  }

  // Kullanıcının giriş yapmış olup olmadığını kontrol etme
  static Future<bool> isUserLoggedIn() async {
    final preferences = await prefs;
    return preferences.getString('uid') != null;
  }

  // Kullanıcı ID'sini alma
  static Future<String?> getUserId() async {
    final preferences = await prefs;
    return preferences.getString('uid');
  }

  // Kullanıcı adını alma
  static Future<String?> getUserName() async {
    final preferences = await prefs;
    return preferences.getString('name');
  }

  // Kullanıcı e-posta adresini alma
  static Future<String?> getUserEmail() async {
    final preferences = await prefs;
    return preferences.getString('email');
  }

  // Kullanıcı bilgilerini güncelleme (kısmi güncelleme için)
  static Future<void> updateUserName(String name) async {
    final preferences = await prefs;
    await preferences.setString('name', name);
  }

  static Future<void> updateUserEmail(String email) async {
    final preferences = await prefs;
    await preferences.setString('email', email);
  }

  // Tüm kullanıcı verilerini alma (debug için)
  static Future<Map<String, dynamic>> getAllUserData() async {
    final preferences = await prefs;
    return {
      'uid': preferences.getString('uid'),
      'name': preferences.getString('name'),
      'email': preferences.getString('email'),
    };
  }

  // Kullanıcı verilerinin varlığını kontrol etme
  static Future<bool> hasUserData() async {
    final preferences = await prefs;
    return preferences.containsKey('uid');
  }

  // Kullanıcı verilerini sıfırlama (tüm verileri silme)
  static Future<void> resetAllData() async {
    final preferences = await prefs;
    await preferences.clear();
  }
} 